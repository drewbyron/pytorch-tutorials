"""
pytorch_tutorials.

"""
__version__='0.2.11',    
__description__='A resource for learning about PyTorch and deep learning.',
__url__='https://github.com/drewbyron/pytorch-tutorials',
__author__='William (Drew) Byron',
__author_email__='william.andrew.byron@gmail.com',
